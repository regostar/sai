# Dzyn 

Design of Experiments with Mixed Factors and Binary Response
Final Year Project PESIT-BSC 2012-16 Bangalore

## Author: Mushtaque Ahamed (Mizzlr)

Implemented Multi-Stage Memetic Algorithm (MSMA)

To run, open terminal and run run.sh
To see the max fitness, run checkMaxFitness.sh
